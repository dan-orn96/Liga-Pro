# LigaPro — nueva base

Paquete inicial limpio para Codespaces: Next.js, TypeScript, panel de propietario con formulario de 8 campos y migración inicial de Supabase.

## Iniciar
Desde la carpeta que contiene `package.json` ejecuta:

```bash
npm install
npm run dev
```

Abre el puerto 3000 en Codespaces.

## Supabase
1. Crea un proyecto en Supabase.
2. Copia Project URL y clave pública (anon/publishable) desde Project Settings → API.
3. Crea `.env.local` en la raíz usando `.env.example` como guía.
4. Ejecuta `supabase/migrations/0001_foundation.sql` desde SQL Editor.

**Importante:** el panel incluido todavía es una demostración en memoria; el formulario no persiste registros en Supabase aún. La migración prepara tablas y activa RLS sin políticas abiertas. Antes de almacenar datos reales hay que configurar autenticación, crear el propietario inicial de forma segura y definir políticas RLS para que cada administrador solo vea su liga. Nunca pongas la clave `service_role` en el navegador.
