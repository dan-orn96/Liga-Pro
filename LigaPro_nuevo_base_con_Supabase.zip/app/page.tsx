"use client";
import { useState } from "react";
import { Trophy, ShieldCheck, Users, BarChart3, Plus, Search, MapPin, CheckCircle2, PauseCircle, Activity, X } from "lucide-react";
type Status = "Activa" | "Pendiente" | "Suspendida";
type League = {id:number;name:string;city:string;modality:string;categories:string;admin:string;email:string;phone:string;status:Status;teams:number};
const initial:League[]=[
{id:1,name:"Liga Municipal del Valle",city:"Naucalpan, Estado de México",modality:"Fútbol 7",categories:"Infantil, Juvenil, Libre",admin:"Administrador principal",email:"admin@ejemplo.com",phone:"55 0000 0000",status:"Activa",teams:24},
{id:2,name:"Liga Deportiva del Centro",city:"Ciudad de México",modality:"Fútbol 11",categories:"Juvenil, Libre, Veteranos",admin:"Jorge Ramírez",email:"jorge@ejemplo.com",phone:"55 0000 0001",status:"Activa",teams:18},
{id:3,name:"Copa Juvenil Metropolitana",city:"Tlalnepantla, Estado de México",modality:"Fútbol rápido",categories:"Infantil, Juvenil",admin:"Sin asignar",email:"—",phone:"—",status:"Pendiente",teams:12}];
export default function Home(){
const [leagues,setLeagues]=useState(initial),[search,setSearch]=useState(""),[modal,setModal]=useState(false);
const [name,setName]=useState(""),[city,setCity]=useState(""),[modality,setModality]=useState("Fútbol 7"),[categories,setCategories]=useState("Infantil, Juvenil, Libre"),[admin,setAdmin]=useState(""),[email,setEmail]=useState(""),[phone,setPhone]=useState(""),[status,setStatus]=useState<Status>("Pendiente");
const filtered=leagues.filter(l=>(l.name+" "+l.city+" "+l.admin).toLowerCase().includes(search.toLowerCase()));
const count=(s:Status)=>leagues.filter(l=>l.status===s).length;
function add(e:React.FormEvent<HTMLFormElement>){e.preventDefault();setLeagues([{id:Date.now(),name,city,modality,categories,admin,email,phone,status,teams:0},...leagues]);setName("");setCity("");setAdmin("");setEmail("");setPhone("");setModal(false);}
function toggle(id:number){setLeagues(ls=>ls.map(l=>l.id===id?{...l,status:l.status==="Activa"?"Suspendida":"Activa"}:l));}
return <main className="shell"><aside className="sidebar"><div className="brand"><Trophy/><b>Liga<span>Pro</span></b></div><p className="sideTag">CONTROL DE PLATAFORMA</p><div className="owner"><ShieldCheck/> Propietario · Acceso general</div><nav><a className="selected">Resumen</a><a>Ligas</a><a>Administradores</a><a>Estadísticas</a><a>Temporadas</a><a>Transmisiones</a><a>Configuración</a></nav><div className="sideFoot">CUENTA PROPIETARIA<br/>Control general</div></aside>
<section className="main"><header><span>Plataforma / <b>Resumen</b></span><span>● Propietario</span></header><div className="content"><div className="intro"><div><small>CENTRO DE CONTROL</small><h1>Panel de control</h1><p>Administra tus ligas y supervisa la actividad de toda la plataforma.</p></div><button className="primary" onClick={()=>setModal(true)}><Plus size={18}/> Registrar nueva liga</button></div>
<div className="banner"><ShieldCheck/><div><b>Tu plataforma, tu control.</b><p>Solo el propietario autoriza ligas y crea administradores.</p></div><strong>ACCESO PRIVADO</strong></div>
<div className="notice">Prototipo inicial: los registros se guardan temporalmente en esta vista. La conexión persistente se configura en la siguiente etapa.</div>
<h2>Resumen general</h2><div className="stats"><Stat title="Ligas registradas" value={leagues.length} icon={<Trophy/>}/><Stat title="Ligas activas" value={count("Activa")} icon={<CheckCircle2/>}/><Stat title="Pendientes" value={count("Pendiente")} icon={<Activity/>}/><Stat title="Suspendidas" value={count("Suspendida")} icon={<PauseCircle/>}/></div>
<div className="tableHead"><div><h2>Gestión de ligas</h2><p>Consulta y administra los espacios deportivos.</p></div><div className="search"><Search size={16}/><input placeholder="Buscar liga..." value={search} onChange={e=>setSearch(e.target.value)}/></div></div>
<div className="tableWrap"><table><thead><tr><th>LIGA / UBICACIÓN</th><th>MODALIDAD</th><th>CATEGORÍAS</th><th>ADMINISTRADOR</th><th>ESTADO</th><th>ACCIÓN</th></tr></thead><tbody>{filtered.map(l=><tr key={l.id}><td><b>{l.name}</b><small><MapPin size={12}/> {l.city}</small></td><td>{l.modality}</td><td>{l.categories}</td><td>{l.admin}<small>{l.email}</small></td><td><span className={"status "+l.status}>{l.status}</span></td><td><button className="action" onClick={()=>toggle(l.id)}>{l.status==="Activa"?"Suspender":"Activar"}</button></td></tr>)}</tbody></table></div>
<div className="bottom"><div><Users/><b>Administradores por liga</b><p>Cada administrador solo podrá gestionar su propia liga.</p></div><div><BarChart3/><b>Supervisión general</b><p>Consulta el crecimiento y actividad de todas las ligas.</p></div></div><footer>© 2026 LigaPro · Hecho para impulsar el deporte.</footer></div></section>
{modal&&<div className="overlay" onClick={e=>{if(e.target===e.currentTarget)setModal(false)}}><form className="modal" onSubmit={add}><div className="modalTitle"><div><small>NUEVO ESPACIO DEPORTIVO</small><h2>Registrar liga</h2></div><button type="button" onClick={()=>setModal(false)}><X/></button></div><div className="formGrid">
<label>Nombre de la liga<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Liga Municipal del Norte"/></label>
<label>Ubicación<input required value={city} onChange={e=>setCity(e.target.value)} placeholder="Ciudad, estado"/></label>
<label>Modalidad principal<select value={modality} onChange={e=>setModality(e.target.value)}><option>Fútbol rápido</option><option>Fútbol 7</option><option>Fútbol 11</option></select></label>
<label>Categorías<input value={categories} onChange={e=>setCategories(e.target.value)}/></label>
<label>Nombre del administrador<input required value={admin} onChange={e=>setAdmin(e.target.value)}/></label>
<label>Correo del administrador<input required type="email" value={email} onChange={e=>setEmail(e.target.value)}/></label>
<label>Teléfono de contacto<input value={phone} onChange={e=>setPhone(e.target.value)}/></label>
<label>Estado inicial<select value={status} onChange={e=>setStatus(e.target.value as Status)}><option>Pendiente</option><option>Activa</option><option>Suspendida</option></select></label></div><p className="hint">La cuenta de administrador se habilitará al configurar Supabase Auth.</p><div className="actions"><button type="button" className="secondary" onClick={()=>setModal(false)}>Cancelar</button><button className="primary"><Plus size={16}/> Agregar liga</button></div></form></div>}</main>}
function Stat({title,value,icon}:{title:string;value:number;icon:React.ReactNode}){return <div className="stat"><div>{icon}</div><strong>{String(value).padStart(2,"0")}</strong><b>{title}</b></div>}
